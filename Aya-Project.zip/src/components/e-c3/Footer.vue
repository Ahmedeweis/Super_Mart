<template>
  <footer class="bg-gray-50 pt-16 pb-8 mt-12">
    <div class="container mx-auto px-4">
      <div class="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
         <div>
            <div class="flex items-center gap-2 mb-4">
               <div class="w-8 h-8 bg-orange-100 rounded text-orange-500 flex items-center justify-center font-bold text-xl">S</div>
               <span class="text-xl font-bold text-gray-900">Super Mart</span>
            </div>
            <p class="text-sm text-gray-500 mb-6 leading-relaxed">
               Lorem ipsum dolor sit amet, consectetur adipiscing elit. At praesent eget mauris felis scelerisque enim enim, magna.
            </p>
         </div>

         <div>
            <h4 class="font-bold text-gray-900 mb-4">Product</h4>
            <ul class="space-y-2 text-sm text-gray-500">
               <li><a href="#" class="text-orange-500 font-medium">>> Shirt</a></li>
               <li><a href="#" class="hover:text-orange-500">Groceries</a></li>
               <li><a href="#" class="hover:text-orange-500 flex items-center gap-2">Computer <span class="text-[10px] bg-green-100 text-green-600 px-1 rounded">New</span></a></li>
               <li><a href="#" class="hover:text-orange-500">Electronics</a></li>
               <li><a href="#" class="hover:text-orange-500">Sports</a></li>
            </ul>
         </div>

         <div>
            <h4 class="font-bold text-gray-900 mb-4">Company</h4>
            <ul class="space-y-2 text-sm text-gray-500">
               <li><a href="#" class="hover:text-orange-500">About us</a></li>
               <li><a href="#" class="hover:text-orange-500">Careers</a></li>
               <li><a href="#" class="hover:text-orange-500">News</a></li>
               <li><a href="#" class="hover:text-orange-500">Media kit</a></li>
               <li><a href="#" class="hover:text-orange-500">Contact</a></li>
            </ul>
         </div>

         <div>
            <h4 class="font-bold text-gray-900 mb-4">Resources</h4>
            <ul class="space-y-2 text-sm text-gray-500">
               <li><a href="#" class="hover:text-orange-500">Blog</a></li>
               <li><a href="#" class="hover:text-orange-500">Newsletter</a></li>
               <li><a href="#" class="hover:text-orange-500">Help centre</a></li>
               <li><a href="#" class="hover:text-orange-500">Tutorials</a></li>
               <li><a href="#" class="hover:text-orange-500">Support</a></li>
            </ul>
         </div>
      </div>
    </div>
  </footer>
</template>

<script setup>
</script>
