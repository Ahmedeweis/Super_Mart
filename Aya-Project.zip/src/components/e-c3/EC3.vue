<template>
  <div class="bg-white font-sans text-gray-700">
    <Header />
    <HeroSection />
    <FeaturesSection />
    <NewArrivals />
    <CategoryIcons />
    <OnSales />
    <Footer />
  </div>
</template>

<script setup>
import Header from './Header.vue'
import HeroSection from './HeroSection.vue'
import FeaturesSection from './FeaturesSection.vue'
import NewArrivals from './NewArrivals.vue'
import CategoryIcons from './CategoryIcons.vue'
import OnSales from './OnSales.vue'
import Footer from './Footer.vue'
</script>
