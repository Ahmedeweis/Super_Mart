<template>
  <div class="bg-white font-sans text-gray-800">
    <Header />
    <HeroSection />
    <CategoryIcons />
    <CategoryCards />
    <TrendingProducts />
    <NewArrivalBanner />
    <WeeklyOffer />
    <FeatureProducts />
    <SmallCategories />
    <SummerCollection />
    <BrandLogos />
  </div>
</template>

<script setup>
import Header from './Header.vue'
import HeroSection from './HeroSection.vue'
import CategoryIcons from './CategoryIcons.vue'
import CategoryCards from './CategoryCards.vue'
import TrendingProducts from './TrendingProducts.vue'
import NewArrivalBanner from './NewArrivalBanner.vue'
import WeeklyOffer from './WeeklyOffer.vue'
import FeatureProducts from './FeatureProducts.vue'
import SmallCategories from './SmallCategories.vue'
import SummerCollection from './SummerCollection.vue'
import BrandLogos from './BrandLogos.vue'
</script>
