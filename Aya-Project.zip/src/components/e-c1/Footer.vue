<template>
  <footer class="bg-white pt-12 md:pt-16 pb-8 mt-8 md:mt-12 border-t border-gray-100">
      <div class="container mx-auto px-4">
        <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-8 mb-12">
            <div>
              <h3 class="text-xl font-bold text-gray-900 mb-4">Emmable</h3>
              <p class="text-gray-500 text-sm mb-4">Easy & reliable online buying and selling site</p>
              <div class="flex gap-4">
                  <a href="#" class="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center text-gray-600 hover:bg-primary hover:text-white transition">f</a>
                  <a href="#" class="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center text-gray-600 hover:bg-primary hover:text-white transition">t</a>
                  <a href="#" class="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center text-gray-600 hover:bg-primary hover:text-white transition">in</a>
              </div>
            </div>

            <div>
              <h4 class="font-bold text-gray-900 mb-4">Company</h4>
              <ul class="space-y-2 text-sm text-gray-500">
                  <li><a href="#" class="hover:text-primary">About Us</a></li>
                  <li><a href="#" class="hover:text-primary">Career</a></li>
                  <li><a href="#" class="hover:text-primary">Privacy Policy</a></li>
                  <li><a href="#" class="hover:text-primary">Blog</a></li>
              </ul>
            </div>

            <div>
              <h4 class="font-bold text-gray-900 mb-4">Buyer</h4>
              <ul class="space-y-2 text-sm text-gray-500">
                  <li><a href="#" class="hover:text-primary">Help</a></li>
                  <li><a href="#" class="hover:text-primary">Payment Method</a></li>
                  <li><a href="#" class="hover:text-primary">Track Buyer Orders</a></li>
                  <li><a href="#" class="hover:text-primary">Free Shipping</a></li>
                  <li><a href="#" class="hover:text-primary">Returns & Funds</a></li>
                  <li><a href="#" class="hover:text-primary">Guarantee</a></li>
              </ul>
            </div>

            <div>
              <h4 class="font-bold text-gray-900 mb-4">Seller</h4>
              <ul class="space-y-2 text-sm text-gray-500">
                  <li><a href="#" class="hover:text-primary">How to Sell</a></li>
                  <li><a href="#" class="hover:text-primary">Sales Profit</a></li>
                  <li><a href="#" class="hover:text-primary">Brand Index</a></li>
                  <li><a href="#" class="hover:text-primary">Track Seller Shipments</a></li>
              </ul>
            </div>
        </div>

        <div class="border-t border-gray-100 pt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-xs text-gray-400">
            <div>&copy; 2023 Emmable. All Rights Reserved.</div>
            <div class="flex gap-4">
              <a href="#">Terms & Conditions</a>
              <a href="#">Privacy Policy</a>
            </div>
        </div>
      </div>
  </footer>
</template>

<script setup>
</script>
