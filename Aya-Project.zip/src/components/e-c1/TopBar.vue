<template>
  <div class="bg-white border-b border-gray-200 text-xs text-gray-500 hidden md:block">
    <div class="container mx-auto px-4 py-2 flex justify-between items-center">
      <div>Call us: (00) 33 169 7720</div>
      <div class="flex items-center gap-4">
        <span>Take 30% off when you spend $99 or more with code "Emmable99" <a href="#" class="text-blue-600 hover:underline">More details</a></span>
        <div class="flex gap-4 ml-4">
          <a href="#" class="hover:text-gray-800">About Emmable</a>
          <a href="#" class="hover:text-gray-800">Help</a>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
</script>
