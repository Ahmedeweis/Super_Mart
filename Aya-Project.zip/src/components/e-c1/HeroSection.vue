<template>
  <section class="container mx-auto px-4 py-4 md:py-6">
    <div class="relative rounded-2xl overflow-hidden h-[200px] sm:h-[300px] md:h-[400px] bg-gradient-to-r from-teal-800 to-teal-600 flex items-center">
      <!-- Background Image Placeholder -->
      <img src="https://placehold.co/1200x400/0f766e/ffffff?text=End+Year+Sale" alt="End Year Sale" class="absolute inset-0 w-full h-full object-cover opacity-50 mix-blend-overlay" />

      <div class="relative z-10 px-6 md:px-12 lg:px-24 text-white w-full">
          <div class="inline-block bg-red-500 text-white text-[10px] md:text-xs font-bold px-2 py-1 rounded mb-2 md:mb-4">1-12 DECEMBER</div>
          <h2 class="text-3xl sm:text-5xl md:text-7xl font-black mb-1 md:mb-2 tracking-tighter leading-tight">SPECIAL <br/> OFFER</h2>
          <div class="text-4xl sm:text-6xl md:text-8xl font-black text-white drop-shadow-lg">
            40% <span class="text-xl sm:text-3xl md:text-5xl align-top">%OFF</span>
          </div>
      </div>
    </div>
  </section>
</template>

<script setup>
</script>
