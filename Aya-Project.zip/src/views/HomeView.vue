<template>
  <EC1 />
  <EC2 />
  <EC3 />
</template>

<script setup>
import EC1 from '../components/e-c1/EC1.vue'
import EC2 from '../components/e-c2/EC2.vue'
import EC3 from '../components/e-c3/EC3.vue'
</script>