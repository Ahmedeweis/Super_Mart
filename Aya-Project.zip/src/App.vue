<template>
    <router-view />
</template>
<script setup>
</script>
<style >
@import url(assets/css/normalize.css);
</style>
